import React from 'react';
import { Clock, BookOpen } from 'lucide-react';
import type { Lesson } from '../../types';

interface LessonCardProps {
  lesson: Lesson;
  onSelect: (lesson: Lesson) => void;
}

export default function LessonCard({ lesson, onSelect }: LessonCardProps) {
  return (
    <div 
      onClick={() => onSelect(lesson)}
      className="bg-white rounded-lg shadow-md p-6 cursor-pointer hover:shadow-lg transition-shadow"
    >
      <h3 className="text-xl font-semibold mb-2">{lesson.title}</h3>
      <p className="text-gray-600 mb-4">{lesson.description}</p>
      
      <div className="flex items-center gap-4 text-sm text-gray-500">
        <div className="flex items-center gap-1">
          <Clock className="w-4 h-4" />
          {lesson.duration}
        </div>
        <div className="flex items-center gap-1">
          <BookOpen className="w-4 h-4" />
          {lesson.difficulty}
        </div>
      </div>
    </div>
  );
}