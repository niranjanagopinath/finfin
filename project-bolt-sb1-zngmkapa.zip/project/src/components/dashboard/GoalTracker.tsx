import React from 'react';
import { Target, TrendingUp } from 'lucide-react';
import type { FinancialGoal } from '../../types';

interface GoalTrackerProps {
  goals: FinancialGoal[];
}

export default function GoalTracker({ goals }: GoalTrackerProps) {
  return (
    <div className="bg-white rounded-lg shadow-lg p-6">
      <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
        <Target className="w-5 h-5" />
        Financial Goals
      </h2>
      
      <div className="space-y-4">
        {goals.map((goal) => {
          const progress = (goal.currentAmount / goal.targetAmount) * 100;
          
          return (
            <div key={goal.id} className="space-y-2">
              <div className="flex justify-between items-center">
                <span className="font-medium">{goal.title}</span>
                <span className="text-sm text-gray-500">
                  ${goal.currentAmount.toLocaleString()} / ${goal.targetAmount.toLocaleString()}
                </span>
              </div>
              
              <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
                <div
                  className="h-full bg-blue-500 transition-all duration-500"
                  style={{ width: `${progress}%` }}
                />
              </div>
              
              <div className="flex justify-between text-sm text-gray-500">
                <span>{progress.toFixed(1)}% Complete</span>
                <span>
                  {new Date(goal.deadline).toLocaleDateString()}
                </span>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}