import React, { useState } from 'react';
import { BookOpen, Users, TrendingUp } from 'lucide-react';
import ChatInterface from './components/chat/ChatInterface';
import LessonCard from './components/lessons/LessonCard';
import GoalTracker from './components/dashboard/GoalTracker';
import type { Lesson, FinancialGoal } from './types';

const SAMPLE_LESSONS: Lesson[] = [
  {
    id: '1',
    title: 'Budgeting Basics',
    duration: '15 mins',
    difficulty: 'beginner',
    description: 'Learn the fundamentals of creating and maintaining a personal budget.'
  },
  {
    id: '2',
    title: 'Investment Fundamentals',
    duration: '20 mins',
    difficulty: 'intermediate',
    description: 'Understanding different investment vehicles and strategies.'
  },
  {
    id: '3',
    title: 'Debt Management',
    duration: '15 mins',
    difficulty: 'beginner',
    description: 'Strategies for managing and reducing personal debt effectively.'
  }
];

const SAMPLE_GOALS: FinancialGoal[] = [
  {
    id: '1',
    title: 'Emergency Fund',
    targetAmount: 10000,
    currentAmount: 3500,
    deadline: new Date('2024-12-31')
  },
  {
    id: '2',
    title: 'Investment Portfolio',
    targetAmount: 50000,
    currentAmount: 15000,
    deadline: new Date('2025-06-30')
  }
];

function App() {
  const [selectedLesson, setSelectedLesson] = useState<Lesson | null>(null);

  return (
    <div className="min-h-screen bg-gray-100">
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 py-4 sm:px-6 lg:px-8">
          <h1 className="text-2xl font-bold text-gray-900 flex items-center gap-2">
            <TrendingUp className="w-6 h-6 text-blue-500" />
            FinanciallyEmpowered
          </h1>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-8 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div className="space-y-8">
            <section>
              <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
                <BookOpen className="w-5 h-5" />
                Financial Lessons
              </h2>
              <div className="grid gap-4">
                {SAMPLE_LESSONS.map((lesson) => (
                  <LessonCard
                    key={lesson.id}
                    lesson={lesson}
                    onSelect={setSelectedLesson}
                  />
                ))}
              </div>
            </section>

            <section>
              <GoalTracker goals={SAMPLE_GOALS} />
            </section>
          </div>

          <div>
            <ChatInterface />
          </div>
        </div>
      </main>
    </div>
  );
}

export default App;